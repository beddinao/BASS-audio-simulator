/*
	BASS DSP example
	Copyright (c) 2000-2021 Un4seen Developments Ltd.
*/

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
@property (weak) IBOutlet NSButton *rotateSwitch;
@property (weak) IBOutlet NSButton *echoSwitch;
@property (weak) IBOutlet NSButton *flangerSwitch;

@end

