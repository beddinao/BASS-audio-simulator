/*
	BASS live spectrum analyser example
	Copyright (c) 2002-2021 Un4seen Developments Ltd.
*/

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
@property (weak) IBOutlet NSButton *specView;
@property (weak) IBOutlet NSTextField *noticeText;

@end

