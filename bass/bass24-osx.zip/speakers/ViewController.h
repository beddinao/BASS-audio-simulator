/*
	BASS multi-speaker example
	Copyright (c) 2003-2021 Un4seen Developments Ltd.
*/

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
@property (weak) IBOutlet NSButton *open1Button;
@property (weak) IBOutlet NSButton *open2Button;
@property (weak) IBOutlet NSButton *open3Button;
@property (weak) IBOutlet NSButton *open4Button;
@property (weak) IBOutlet NSButton *swap12Button;
@property (weak) IBOutlet NSButton *swap23Button;
@property (weak) IBOutlet NSButton *swap34Button;

@end

